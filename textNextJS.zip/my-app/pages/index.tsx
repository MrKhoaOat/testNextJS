import React,{useState} from "react";
import { seriesProp } from "../interfaces/type";
import List from "../components/list"
import Form from "../components/form";
import styles from '../styles/styles.module.css'



export default function App(){
    const [seriesList,setSeriesList] = useState<seriesProp["seriesList"]>([]);

    return (
        <div className={styles.backGround}>
            <h1 className={styles.hText}>My Movie</h1>
            <Form seriesList={seriesList} setSeriesList={setSeriesList}/>
            <List seriesList={seriesList} />
        </div>
    )
}