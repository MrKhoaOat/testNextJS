import React,{FC,ChangeEvent,MouseEvent,useState,Dispatch,SetStateAction} from 'react'
import { seriesProp } from '../interfaces/type'
import {InputNumber,Input,Button} from 'antd';
import { PoweroffOutlined } from '@ant-design/icons';
import styles from '../styles/styles.module.css'

interface Prop{
    seriesList:seriesProp["seriesList"]
    setSeriesList:Dispatch<SetStateAction<seriesProp["seriesList"]>>
}

const Form:FC<Prop> = ({seriesList,setSeriesList}) => {

    const [name,setName] = useState("");
    const [imdb,setImdb] = useState<seriesProp | any >(0);
    const [cover,setCover] = useState("");
    const [seasons,setSeasons] = useState<seriesProp | any >(0);
    const [genre,setGenre] = useState("");



    const setNameInputHandler = (event: ChangeEvent<HTMLInputElement>) => {
        setName(event.target.value)
    }
    const setGenreInputHandler = (event: ChangeEvent<HTMLInputElement>) => {
        setGenre(event.target.value)
    }
    const setCoverInputHandler = (event: ChangeEvent<HTMLInputElement>) => {
        setCover(event.target.value)
    }
    const setImdbInputHandler = (event: ChangeEvent<HTMLInputElement>) => {
        setImdb(event.target.value)
    }
    const setSeasonsInputHandler = (event: ChangeEvent<HTMLInputElement>) => {
        setSeasons(event.target.value)
    }
   const HandleClick = (event: MouseEvent<HTMLButtonElement>) => {
        if(!name && !genre && !cover && !imdb && !seasons) {
            alert("Please enter series info");
            return
        }
        const seriesData = {name, genre, cover, imdb, seasons}
        setSeriesList([...seriesList,seriesData])
        setName("");
        setGenre("");
        setCover("");
        setImdb(0);
        setSeasons(0);
    }

  return (
    <div id="Form" className={styles.div}>
      <h1 className={styles.hText}>Choose Favorite Movie</h1>
      <div className="form-container">
        <div className="form-contain">
            <div className="form-dev">
                <Input addonBefore="Name" type="text" name="name" value={name} onChange={setNameInputHandler} style={{ width: 300,height: 50 }} />
            </div>
            <div className="form-dev">
                <Input addonBefore="Genre" type="text" name="genre" value={genre} onChange={setGenreInputHandler} style={{ width: 300,height: 50 }} />
            </div>
            <div className="form-dev">
                <Input addonBefore="Cover" type="text" name="cover" value={cover} onChange={setCoverInputHandler} style={{ width: 300,height: 50 }} />
            </div> 
            <div className="form-dev">   
                <Input addonBefore="IMDB" addonAfter="⭐" type="number" name="imdb" value={imdb} onChangeCapture={setImdbInputHandler} style={{ width: 300,height: 50 }}/>
            </div>
            <div className="form-dev">  
                <Input addonBefore="Season" type="number" name="seasons" value={seasons}  onChangeCapture={setSeasonsInputHandler} style={{ width: 300,height: 50 }}/>
            </div>
            <div className={styles.div}>
            <Button className={styles.button}
            type="primary"
            icon={<PoweroffOutlined />}
            onClickCapture={HandleClick}
            >
            Click me!
            </Button>
            </div>
           
        </div>
      </div>
    </div>
  )
}

export default Form
