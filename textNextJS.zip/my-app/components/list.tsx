import React,{FC} from 'react'
import { seriesProp } from '../interfaces/type'
import styles from '../styles/styles.module.css'


const List:FC<seriesProp> = ({seriesList}) => {
    return (
    <div className={styles.div}>
        <h1 className={styles.hText}>Favorite Movie</h1>
        {seriesList.map((series,index) => (
            <div key={index} className={styles.divText}>
                <img src={series.cover} alt="series-cover"/>
                <p>Movie Name: <b>{series.name}</b></p>
                <p>Genre: {series.genre}</p>
                <p>⭐{series.imdb}</p>
                <p>Season: {series.seasons}</p>

            </div>
        ) 
        )}
    </div>
)}

export default List
