export interface seriesProp {
    seriesList:{
    name: string;
    imdb:number;
    cover:string;
    seasons:number;
    genre:string;
}[]
}